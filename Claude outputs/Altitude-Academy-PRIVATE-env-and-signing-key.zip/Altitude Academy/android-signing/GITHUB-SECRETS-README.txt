ALTITUDE ACADEMY ANDROID APP — SIGNING KEY  (KEEP PRIVATE · NEVER COMMIT · BACK IT UP)
======================================================================================
This folder is git-ignored. It holds the key that signs every version of the
Altitude Academy Android app (a different key from AeroGyan's). Android only
installs an UPDATE if it is signed with this same key — if it is lost, students
would have to uninstall and reinstall. Copy this folder somewhere safe now.

Add these 4 secrets once on GitHub, in the Altitude Academy repository:
  Repository → Settings → Secrets and variables → Actions → "New repository secret"

  Name: ANDROID_KEYSTORE_BASE64
  Value: the whole contents of release-keystore.base64.txt (one long line)

  Name: ANDROID_KEYSTORE_PASSWORD
  Value: 1WpzKLFaTTVw5nZbCMfT8sWL

  Name: ANDROID_KEY_ALIAS
  Value: altitudeacademy

  Name: ANDROID_KEY_PASSWORD
  Value: 1WpzKLFaTTVw5nZbCMfT8sWL

Certificate SHA-256 fingerprint (for reference / Play Store / App Links):
  42:28:26:CA:D1:08:7D:BA:C3:40:23:AB:41:1A:FA:4F:C6:65:E3:5E:B5:CA:BB:27:18:3C:39:69:25:B2:F1:C7
